//
//  AppDelegate.h
//  YPVerifyDemo
//
//  Created by daizq on 2019/4/22.
//  Copyright © 2019 QiPeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
